package com.resultcopy;

import lombok.Getter;
import lombok.Setter;
import org.joda.time.DateTime;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class PatientResult {
    private Patient patient = new Patient();
    private List<Child> child = new ArrayList<>();
    private List<Category> category = new ArrayList<>();
    private DateTime resultCopiedDateTime ;

}
