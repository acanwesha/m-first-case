package com.resultcopy.rest.api.impl;


import com.resultcopy.rest.api.ApiResponseMessage;
import com.resultcopy.rest.api.PatientResultsApiService;

import com.resultcopy.rest.api.NotFoundException;
import com.resultcopy.rest.model.Patient;
import com.resultcopy.service.dao.PatientDAO;
import com.resultcopy.service.impl.PatientDAOImpl;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaJerseyServerCodegen", date = "2021-06-10T12:22:56.778Z[GMT]")public class PatientResultsApiServiceImpl extends PatientResultsApiService {
    @Override
    public Response patientResultsPatientIdGet(String patientId, SecurityContext securityContext) throws NotFoundException {

        PatientDAOImpl dao = new PatientDAOImpl();
        Patient patient =dao.getPatientById(Integer.parseInt(patientId));
        
        return Response.ok().entity(patient).build();
    }
}
