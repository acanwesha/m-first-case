package com.resultcopy.service.dao;

import com.resultcopy.rest.model.Patient;

public interface PatientDAO {

    Patient getPatientById(Integer patientId);
}
