package com.resultcopy.service.serviceimpl;

public class PatientServiceImpl {
}
